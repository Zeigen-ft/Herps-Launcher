execute if entity @s[tag=herps_dl.level15] if block ~ ~ ~ minecraft:light[level=15,waterlogged=false] run setblock ~ ~ ~ minecraft:air
execute if entity @s[tag=herps_dl.level14] if block ~ ~ ~ minecraft:light[level=14,waterlogged=false] run setblock ~ ~ ~ minecraft:air
execute if entity @s[tag=herps_dl.level10] if block ~ ~ ~ minecraft:light[level=10,waterlogged=false] run setblock ~ ~ ~ minecraft:air
execute if entity @s[tag=herps_dl.level7] if block ~ ~ ~ minecraft:light[level=7,waterlogged=false] run setblock ~ ~ ~ minecraft:air
kill @s
