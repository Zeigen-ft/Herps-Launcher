execute in minecraft:overworld as @e[type=minecraft:marker,tag=herps_dl.owned] at @s run function herps_dl:remove
execute in minecraft:the_nether as @e[type=minecraft:marker,tag=herps_dl.owned] at @s run function herps_dl:remove
execute in minecraft:the_end as @e[type=minecraft:marker,tag=herps_dl.owned] at @s run function herps_dl:remove
execute if score #enabled herps_dl matches 1 run function herps_dl:sources
