execute store success score #claimed herps_dl run summon minecraft:marker ~ ~ ~ {Tags:["herps_dl.owned","herps_dl.level14"]}
execute if score #claimed herps_dl matches 1 run setblock ~ ~ ~ minecraft:light[level=14,waterlogged=false]
