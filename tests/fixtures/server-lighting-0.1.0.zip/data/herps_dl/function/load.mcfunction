scoreboard objectives add herps_dl dummy
execute unless score #enabled herps_dl matches 0..1 run scoreboard players set #enabled herps_dl 0
