scoreboard players set #enabled herps_dl 1
