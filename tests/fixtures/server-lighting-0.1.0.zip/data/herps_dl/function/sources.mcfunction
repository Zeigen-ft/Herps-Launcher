execute as @a at @s if items entity @s weapon.* #herps_dl:level15 positioned ~ ~1 ~ run function herps_dl:place15
execute as @a at @s as @e[type=minecraft:item,distance=..24,limit=32,sort=nearest] at @s if items entity @s contents #herps_dl:level15 run function herps_dl:place15
execute as @a at @s if items entity @s weapon.* #herps_dl:level14 positioned ~ ~1 ~ run function herps_dl:place14
execute as @a at @s as @e[type=minecraft:item,distance=..24,limit=32,sort=nearest] at @s if items entity @s contents #herps_dl:level14 run function herps_dl:place14
execute as @a at @s if items entity @s weapon.* #herps_dl:level10 positioned ~ ~1 ~ run function herps_dl:place10
execute as @a at @s as @e[type=minecraft:item,distance=..24,limit=32,sort=nearest] at @s if items entity @s contents #herps_dl:level10 run function herps_dl:place10
execute as @a at @s if items entity @s weapon.* #herps_dl:level7 positioned ~ ~1 ~ run function herps_dl:place7
execute as @a at @s as @e[type=minecraft:item,distance=..24,limit=32,sort=nearest] at @s if items entity @s contents #herps_dl:level7 run function herps_dl:place7
