scoreboard players set #enabled herps_dl 0
execute in minecraft:overworld as @e[type=minecraft:marker,tag=herps_dl.owned] at @s run function herps_dl:remove
execute in minecraft:the_nether as @e[type=minecraft:marker,tag=herps_dl.owned] at @s run function herps_dl:remove
execute in minecraft:the_end as @e[type=minecraft:marker,tag=herps_dl.owned] at @s run function herps_dl:remove
