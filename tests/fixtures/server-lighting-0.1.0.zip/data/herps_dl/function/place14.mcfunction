execute align xyz positioned ~0.5 ~ ~0.5 if block ~ ~ ~ minecraft:air run function herps_dl:claim14
